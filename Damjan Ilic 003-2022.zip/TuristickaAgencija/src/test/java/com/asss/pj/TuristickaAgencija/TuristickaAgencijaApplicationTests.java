package com.asss.pj.TuristickaAgencija;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TuristickaAgencijaApplicationTests {

	@Test
	void contextLoads() {
	}

}
