package com.asss.pj.TuristickaAgencija.repo;

import com.asss.pj.TuristickaAgencija.entity.Klijent;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KlijentRepo extends JpaRepository<Klijent, Integer> {
}
