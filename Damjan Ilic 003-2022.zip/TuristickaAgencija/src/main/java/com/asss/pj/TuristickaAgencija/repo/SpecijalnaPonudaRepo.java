package com.asss.pj.TuristickaAgencija.repo;

import com.asss.pj.TuristickaAgencija.entity.SpecijalnaPonuda;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpecijalnaPonudaRepo extends JpaRepository<SpecijalnaPonuda, Integer> {

}