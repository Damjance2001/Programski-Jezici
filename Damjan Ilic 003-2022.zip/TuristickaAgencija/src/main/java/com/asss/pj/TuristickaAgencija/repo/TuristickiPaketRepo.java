package com.asss.pj.TuristickaAgencija.repo;

import com.asss.pj.TuristickaAgencija.entity.TuristickiPaket;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TuristickiPaketRepo extends JpaRepository<TuristickiPaket, Integer> {
}
